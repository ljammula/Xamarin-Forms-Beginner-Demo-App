﻿namespace BethanysPieShop.API.Models
{
    public class ContactInfo
    {
        public int ContactInfoId { get; set; }
        public string Email { get; set; }
        public string Message { get; set; }
    }
}
