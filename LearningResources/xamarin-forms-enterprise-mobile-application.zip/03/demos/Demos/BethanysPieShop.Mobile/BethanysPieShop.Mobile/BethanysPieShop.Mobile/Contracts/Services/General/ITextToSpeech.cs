﻿namespace BethanysPieShop.Mobile.Core.Contracts.Services.General
{
    public interface ITextToSpeech
    {
        void ReadText(string text);
    }
}
