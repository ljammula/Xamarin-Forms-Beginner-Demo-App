﻿using System.Threading.Tasks;

namespace BethanysPieShop.Mobile.Core.Contracts.Services.General
{
    public interface IDialogService
    {
        Task ShowDialog(string message, string title, string buttonLabel);

        void ShowToast(string message);
    }
}
