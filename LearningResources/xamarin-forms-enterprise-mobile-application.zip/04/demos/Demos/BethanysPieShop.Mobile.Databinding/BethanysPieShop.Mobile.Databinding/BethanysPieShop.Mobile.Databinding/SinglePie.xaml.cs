﻿using BethanysPieShop.Mobile.Databinding.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BethanysPieShop.Mobile.Databinding
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class SinglePie : ContentPage
	{
		public SinglePie ()
		{
			InitializeComponent ();

            var pie = new MockPieRepository().GetSinglePie();

            this.BindingContext = pie;
		}
	}
}