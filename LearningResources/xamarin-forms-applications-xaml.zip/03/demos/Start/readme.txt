In the demos, we start from the empty template, so there's no starter solution for this module.

Refer to the end solution to find the finished application for this module.