﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace BethanysPieShopMobile
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            Label titleLabel = new Label();
            titleLabel.Text = "Bethany's Pie Shop";
            titleLabel.FontSize = 14;

        }

        private void DemoButton_Clicked(object sender, EventArgs e)
        {
            DemoButton.Text = "I was clicked";
        }
    }
}
