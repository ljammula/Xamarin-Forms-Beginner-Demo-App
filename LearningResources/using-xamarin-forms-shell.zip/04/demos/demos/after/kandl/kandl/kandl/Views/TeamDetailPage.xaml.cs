﻿using kandl.Services;
using kandl.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace kandl.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TeamDetailPage : ContentPage
    {
        public TeamDetailPage()
        {
            InitializeComponent();
        }

        // define first
        public TeamDetailPage(TeamDetailViewModel viewModel) : this()
        {
            BindingContext = viewModel;
        }
    }
}