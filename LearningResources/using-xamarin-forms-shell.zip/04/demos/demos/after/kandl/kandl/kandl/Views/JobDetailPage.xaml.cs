﻿using kandl.Models;
using kandl.Services;
using kandl.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace kandl.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class JobDetailPage : ContentPage
    {
        public JobDetailPage()
        {
            InitializeComponent();
        }

        public JobDetailPage(JobDetailViewModel viewModel) : this()
        {
            BindingContext = viewModel;
        }

    }
}