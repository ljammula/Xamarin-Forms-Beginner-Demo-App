﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;
using kandl.Models;
using System.Linq;
using System.Threading.Tasks;

namespace kandl.Services
{
    public class JobSearchHandler : SearchHandler
    {
        protected override void OnQueryChanged(string oldValue, string newValue)
        {
            base.OnQueryChanged(oldValue, newValue);

            if (string.IsNullOrWhiteSpace(newValue))
            {
                ItemsSource = null;
            }
            else
            {
                var DataStore = ((App)App.Current).JobsDataStore;

                ItemsSource = DataStore.GetTeamJobs()
                    .Where(j => j.Tags.Contains(newValue, StringComparer.OrdinalIgnoreCase))
                    .ToList<TeamJob>();
            }
        }

        protected override async void OnItemSelected(object item)
        {
            base.OnItemSelected(item);

            var s = $"jobdetail?id={((TeamJob)item).ID}";

            // work around for https://github.com/xamarin/Xamarin.Forms/issues/5713
            await Task.Delay(500);

            await Shell.Current.GoToAsync(s, true);
        }
    }
}
