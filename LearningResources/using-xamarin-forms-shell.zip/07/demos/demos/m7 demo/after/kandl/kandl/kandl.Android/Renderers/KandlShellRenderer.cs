﻿using Android.Content;
using Android.Graphics.Drawables;
using Android.Support.Design.Widget;
using System;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ExportRenderer(typeof(Shell), typeof(kandl.Droid.Renderers.KandlShellRenderer))]
namespace kandl.Droid.Renderers
{
    public class KandlShellRenderer : ShellRenderer
    {
        public KandlShellRenderer(Context context) : base(context) { }

        protected override IShellFlyoutContentRenderer CreateShellFlyoutContentRenderer()
        {
            var flyout =  base.CreateShellFlyoutContentRenderer();

            GradientDrawable gradient = new GradientDrawable(
                GradientDrawable.Orientation.BottomTop,
                new Int32[]
                {
                    ((Color)App.LookupColor("FlyoutGradientEnd")).ToAndroid(),
                    ((Color)App.LookupColor("FlyoutGradientStart")).ToAndroid()
                });

            var cl = ((CoordinatorLayout)flyout.AndroidView);
            cl.SetBackground(gradient);

            var g = (AppBarLayout)cl.GetChildAt(0);
            g.SetBackgroundColor(Color.Transparent.ToAndroid());
            g.OutlineProvider = null;

            var header = g.GetChildAt(0);
            header.SetBackgroundColor(Color.Transparent.ToAndroid());

            return flyout;
        }
    }
}