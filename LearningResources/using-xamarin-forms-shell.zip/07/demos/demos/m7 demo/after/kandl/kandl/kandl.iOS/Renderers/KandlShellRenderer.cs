﻿using System;
using CoreAnimation;
using CoreGraphics;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(Shell), typeof(kandl.iOS.Renderers.KandlShellRenderer))]
namespace kandl.iOS.Renderers
{
    public class KandlShellRenderer : ShellRenderer
    {
        private CAGradientLayer _flyoutBackground = null;

        private void OnFlyoutWillAppear(object sender, EventArgs e)
        {
            if (_flyoutBackground == null && sender != null && sender is IShellFlyoutContentRenderer flyout)
            {
                var v = flyout.ViewController.View;

                _flyoutBackground = new CAGradientLayer
                {
                    Frame = new CGRect(0, 0, v.Bounds.Width, v.Bounds.Height)
                };

                _flyoutBackground.Colors = new CoreGraphics.CGColor[]
                {
                    ((Color)App.LookupColor("FlyoutGradientStart")).ToCGColor(),
                    ((Color)App.LookupColor("FlyoutGradientEnd")).ToCGColor()
                };

                flyout.ViewController.View.Layer.InsertSublayer(_flyoutBackground, 0);

                flyout.WillAppear -= OnFlyoutWillAppear;

            }
        }

        protected override IShellFlyoutContentRenderer CreateShellFlyoutContentRenderer()
        {
            var flyout = base.CreateShellFlyoutContentRenderer();
            flyout.WillAppear += OnFlyoutWillAppear;

            var tv = (UITableView)flyout.ViewController.View.Subviews[0];
            var tvs = (ShellTableViewSource)tv.Source;
            tvs.Groups.RemoveAt(1);

            return flyout;
        }
    }
}