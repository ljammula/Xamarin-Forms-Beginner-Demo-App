﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace HeaderDemo
{
    public class FlyoutItemSelector : DataTemplateSelector
    {
        public DataTemplate HeaderTemplate { get; set; }
        public DataTemplate HeaderTemplateBottom { get; set; }
        public DataTemplate ItemTemplate { get; set; }
        protected override DataTemplate OnSelectTemplate(object item, BindableObject container)
        {
            if (item is FlyoutItem flyoutItem)
            {
                if (flyoutItem.Route.ToLower().StartsWith("header"))
                {
                    return String.IsNullOrEmpty(flyoutItem.Title) ? HeaderTemplateBottom : HeaderTemplate;
                }
            }
            return ItemTemplate;
        }
    }
}
