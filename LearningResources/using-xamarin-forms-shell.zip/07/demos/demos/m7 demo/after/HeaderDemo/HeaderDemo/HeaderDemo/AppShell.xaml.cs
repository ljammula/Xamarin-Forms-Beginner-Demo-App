﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace HeaderDemo
{
    public partial class AppShell : Xamarin.Forms.Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}
